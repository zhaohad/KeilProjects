/**
  ******************************************************************************
  * @file    stm8l10x_gpio.c
  * @author  MCD Application Team
  * @version V1.2.0
  * @date    01-June-2012
  * @brief   This file contains all the functions for the GPIO peripheral.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2012 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm8l10x_gpio.h"

/** @addtogroup STM8L10x_StdPeriph_Driver
  * @{
  */
/** @defgroup GPIO 
  * @brief GPIO driver modules
  * @{
  */ 
  
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


/**
  * @addtogroup GPIO_Private_Functions
  * @{
  */

/**
  * @brief  Deinitializes the GPIOx peripheral registers to their default reset values.
  * @param  GPIOx Select the GPIO peripheral number (x = A to D).
  * @retval None
  */
void GPIO_DeInit(GPIO_TypeDef* GPIOx)
{
  GPIOx->ODR = GPIO_ODR_RESET_VALUE; /* Reset Output Data Register */
  GPIOx->DDR = GPIO_DDR_RESET_VALUE; /* Reset Data Direction Register */
  GPIOx->CR1 = GPIO_CR1_RESET_VALUE; /* Reset Control Register 1 */
  GPIOx->CR2 = GPIO_CR2_RESET_VALUE; /* Reset Control Register 2 */
}

/**
  * @brief  Initializes the GPIOx according to the specified parameters.
  * @param  GPIOx     Select the GPIO peripheral number (x = A to D).
  * @param  GPIO_Pin  This parameter contains the pin number
  *          This parameter can be any combination of the following values:
  *            @arg GPIO_Pin_0:   GPIO Pin 0
  *            @arg GPIO_Pin_1:   GPIO Pin 1
  *            @arg GPIO_Pin_2:   GPIO Pin 2
  *            @arg GPIO_Pin_3:   GPIO Pin 3
  *            @arg GPIO_Pin_4:   GPIO Pin 4
  *            @arg GPIO_Pin_5:   GPIO Pin 5
  *            @arg GPIO_Pin_6:   GPIO Pin 6
  *            @arg GPIO_Pin_7:   GPIO Pin 7
  *            @arg GPIO_Pin_LNib:  Low nibble pins
  *            @arg GPIO_Pin_HNib:  High nibble pins
  *            @arg GPIO_Pin_All:   All pins                    
  * @param  GPIO_Mode Select the mode
  *          This parameter can be any combination of the following values:
  *           This parameter can be one of the following values:
  *            @arg GPIO_Mode_In_FL_No_IT: Input floating, no external interrupt
  *            @arg GPIO_Mode_In_PU_No_IT: Input pull-up, no external interrupt
  *            @arg GPIO_Mode_In_FL_IT: Input floating, external interrupt
  *            @arg GPIO_Mode_In_PU_IT: Input pull-up, external interrupt  
  *            @arg GPIO_Mode_Out_OD_Low_Fast: Output open-drain, low level, 10MHz
  *            @arg GPIO_Mode_Out_PP_Low_Fast: Output push-pull, low level, 10MHz
  *            @arg GPIO_Mode_Out_OD_Low_Slow: Output open-drain, low level, 2MHz
  *            @arg GPIO_Mode_Out_PP_Low_Slow: Output push-pull, low level, 2MHz
  *            @arg GPIO_Mode_Out_OD_HiZ_Fast: Output open-drain, high-impedance level, 10MHz
  *            @arg GPIO_Mode_Out_PP_High_Fast: Output push-pull, high level, 10MHz
  *            @arg GPIO_Mode_Out_OD_HiZ_Slow: Output open-drain, high-impedance level, 2MHz
  *            @arg GPIO_Mode_Out_PP_High_Slow: Output push-pull, high level, 2MHz
  * @retval None
  */
void GPIO_Init(GPIO_TypeDef* GPIOx,
               uint8_t GPIO_Pin,
               GPIO_Mode_TypeDef GPIO_Mode)
{
  /*----------------------*/
  /* Check the parameters */
  /*----------------------*/

  assert_param(IS_GPIO_MODE(GPIO_Mode));
  assert_param(IS_GPIO_PIN(GPIO_Pin));

  /*-----------------------------*/
  /* Input/Output mode selection */
  /*-----------------------------*/

  if ((((uint8_t)(GPIO_Mode)) & (uint8_t)0x80) != (uint8_t)0x00) /* Output mode */
  {
    if ((((uint8_t)(GPIO_Mode)) & (uint8_t)0x10) != (uint8_t)0x00) /* High level */
    {
      GPIOx->ODR |= GPIO_Pin;
    } else /* Low level */
    {
      GPIOx->ODR &= (uint8_t)(~(GPIO_Pin));
    }
    /* Set Output mode */
    GPIOx->DDR |= GPIO_Pin;
  } else /* Input mode */
  {
    /* Set Input mode */
    GPIOx->DDR &= (uint8_t)(~(GPIO_Pin));
  }

  /*------------------------------------------------------------------------*/
  /* Pull-Up/Float (Input) or Push-Pull/Open-Drain (Output) modes selection */
  /*------------------------------------------------------------------------*/

  if ((((uint8_t)(GPIO_Mode)) & (uint8_t)0x40) != (uint8_t)0x00) /* Pull-Up or Push-Pull */
  {
    GPIOx->CR1 |= GPIO_Pin;
  } else /* Float or Open-Drain */
  {
    GPIOx->CR1 &= (uint8_t)(~(GPIO_Pin));
  }

  /*-----------------------------------------------------*/
  /* Interrupt (Input) or Slope (Output) modes selection */
  /*-----------------------------------------------------*/

  if ((((uint8_t)(GPIO_Mode)) & (uint8_t)0x20) != (uint8_t)0x00) /* Interrupt or Slow slope */
  {
    GPIOx->CR2 |= GPIO_Pin;
  } else /* No external interrupt or No slope control */
  {
    GPIOx->CR2 &= (uint8_t)(~(GPIO_Pin));
  }

}

/**
  * @brief  Writes data to the specified GPIO data port.
  * @note   The port must be configured in output mode.
  * @param  GPIOx  Select the GPIO peripheral number (x = A to D).
  * @param  GPIO_PortVal Specifies the value to be written to the port output data register.
  * @retval None
  */
void GPIO_Write(GPIO_TypeDef* GPIOx, uint8_t GPIO_PortVal)
{
  GPIOx->ODR = GPIO_PortVal;
}

/**
  * @brief  Sets or clears the selected data port bit.
  * @param  GPIOx       Select the GPIO peripheral number (x = A to D).
  * @param  GPIO_Pin: Specifies the port bit to be written.
  *           This parameter can be one of the following values:
  *            @arg GPIO_Pin_0: Pin 0
  *            @arg GPIO_Pin_1: Pin 1
  *            @arg GPIO_Pin_2: Pin 2
  *            @arg GPIO_Pin_3: Pin 3
  *            @arg GPIO_Pin_4: Pin 4
  *            @arg GPIO_Pin_5: Pin 5
  *            @arg GPIO_Pin_6: Pin 6
  *            @arg GPIO_Pin_7: Pin 7   
  * @param  GPIO_BitVal: specifies the desired status to be written.
  *         This parameter can be SET or RESET
  * @retval None
  */
void GPIO_WriteBit(GPIO_TypeDef* GPIOx, GPIO_Pin_TypeDef GPIO_Pin, BitAction GPIO_BitVal)
{
  /* Check the parameters */
  assert_param(IS_GPIO_PIN(GPIO_Pin));
  assert_param(IS_STATE_VALUE(GPIO_BitVal));

  if (GPIO_BitVal != RESET)
  {
    SetBit(GPIOx->ODR, GPIO_Pin);

  }
  else
  {
    ClrBit(GPIOx->ODR, GPIO_Pin);
  }
}

/**
  * @brief  Writes high level to the specified GPIO pins.
  * @note   The port must be configured in output mode.
  * @param  GPIOx    Select the GPIO peripheral number (x = A to D).
  * @param  GPIO_Pin : Specifies the pins to be turned high.
  *           This parameter can be one of the following values:
  *            @arg GPIO_Pin_0: Pin 0
  *            @arg GPIO_Pin_1: Pin 1
  *            @arg GPIO_Pin_2: Pin 2
  *            @arg GPIO_Pin_3: Pin 3
  *            @arg GPIO_Pin_4: Pin 4
  *            @arg GPIO_Pin_5: Pin 5
  *            @arg GPIO_Pin_6: Pin 6
  *            @arg GPIO_Pin_7: Pin 7.
  * @retval None
  */
void GPIO_SetBits(GPIO_TypeDef* GPIOx, uint8_t GPIO_Pin)
{
  GPIOx->ODR |= GPIO_Pin;
}

/**
  * @brief  Writes low level to the specified GPIO pins.
  * @note   The port must be configured in output mode.
  * @param  GPIOx    Select the GPIO peripheral number (x = A to D).
  * @param  GPIO_Pin : Specifies the pins to be turned low
  *           This parameter can be one of the following values:
  *            @arg GPIO_Pin_0: Pin 0
  *            @arg GPIO_Pin_1: Pin 1
  *            @arg GPIO_Pin_2: Pin 2
  *            @arg GPIO_Pin_3: Pin 3
  *            @arg GPIO_Pin_4: Pin 4
  *            @arg GPIO_Pin_5: Pin 5
  *            @arg GPIO_Pin_6: Pin 6
  *            @arg GPIO_Pin_7: Pin 7 
  * @retval None
  */
void GPIO_ResetBits(GPIO_TypeDef* GPIOx, uint8_t GPIO_Pin)
{
  GPIOx->ODR &= (uint8_t)(~GPIO_Pin);
}

/**
  * @brief  Toggles the specified GPIO pins.
  * @note   The port must be configured in output mode.
  * @param  GPIOx    Select the GPIO peripheral number (x = A to D).
  * @param  GPIO_Pin Specifies the pins to be toggled data register.
  * @retval None
  */
void GPIO_ToggleBits(GPIO_TypeDef* GPIOx, uint8_t GPIO_Pin)
{
  GPIOx->ODR ^= GPIO_Pin;
}

/**
  * @brief  Reads the specified GPIO input data port.
  * @note   The port must be configured in input mode.
  * @param  GPIOx Select the GPIO peripheral number (x = A to D).
  * @retval uint8_t GPIO input data port value.
  */
uint8_t GPIO_ReadInputData(GPIO_TypeDef* GPIOx)
{
  return ((uint8_t)GPIOx->IDR);
}

/**
  * @brief  Reads the specified GPIO output data port.
  * @note   The port must be configured in input mode.
  * @param  GPIOx Select the GPIO peripheral number (x = A to D).
  * @retval uint8_t GPIO output data port value.
  */
uint8_t GPIO_ReadOutputData(GPIO_TypeDef* GPIOx)
{
  return ((uint8_t)GPIOx->ODR);
}

/**
  * @brief  Reads the specified GPIO input data pin.
  * @note   The port must be configured in output mode.
  * @param  GPIOx    Select the GPIO peripheral number (x = A to D).
  * @param  GPIO_Pin This parameter contains the pin number
  *           This parameter can be one of the following values:
  *            @arg GPIO_Pin_0: Pin 0
  *            @arg GPIO_Pin_1: Pin 1
  *            @arg GPIO_Pin_2: Pin 2
  *            @arg GPIO_Pin_3: Pin 3
  *            @arg GPIO_Pin_4: Pin 4
  *            @arg GPIO_Pin_5: Pin 5
  *            @arg GPIO_Pin_6: Pin 6
  *            @arg GPIO_Pin_7: Pin 7   
  * @retval BitStatus GPIO input pin status.
  */
BitStatus GPIO_ReadInputDataBit(GPIO_TypeDef* GPIOx, GPIO_Pin_TypeDef GPIO_Pin)
{
  return ((BitStatus)(GPIOx->IDR & (uint8_t)GPIO_Pin));
}

/**
  * @brief  Reads the specified GPIO Output data pin.
  * @note   The port must be configured in input mode.
  * @param  GPIOx    Select the GPIO peripheral number (x = A to D).
  * @param  GPIO_Pin This parameter contains the pin number
  *           This parameter can be one of the following values:
  *            @arg GPIO_Pin_0: Pin 0
  *            @arg GPIO_Pin_1: Pin 1
  *            @arg GPIO_Pin_2: Pin 2
  *            @arg GPIO_Pin_3: Pin 3
  *            @arg GPIO_Pin_4: Pin 4
  *            @arg GPIO_Pin_5: Pin 5
  *            @arg GPIO_Pin_6: Pin 6
  *            @arg GPIO_Pin_7: Pin 7   
  * @retval GPIO output pin status.
  */
BitStatus GPIO_ReadOutputDataBit(GPIO_TypeDef* GPIOx, GPIO_Pin_TypeDef GPIO_Pin)
{
  return ((BitStatus)(GPIOx->ODR & (uint8_t)GPIO_Pin));
}

/**
  * @brief  Configures the external pull-up on GPIOx pins.
  * @param  GPIOx    Select the GPIO peripheral number (x = A to D).
  * @param  GPIO_Pin : Specifies the pin number
  *           This parameter can be one of the following values:
  *            @arg GPIO_Pin_0: Pin 0
  *            @arg GPIO_Pin_1: Pin 1
  *            @arg GPIO_Pin_2: Pin 2
  *            @arg GPIO_Pin_3: Pin 3
  *            @arg GPIO_Pin_4: Pin 4
  *            @arg GPIO_Pin_5: Pin 5
  *            @arg GPIO_Pin_6: Pin 6
  *            @arg GPIO_Pin_7: Pin 7     
  * @param  NewState : The new state of the pull up pin.
  *           Can be ENABLE or DISABLE  
  * @retval None
  */
void GPIO_ExternalPullUpConfig(GPIO_TypeDef* GPIOx, uint8_t GPIO_Pin, FunctionalState NewState)
{
  /* Check the parameters */
  assert_param(IS_GPIO_PIN(GPIO_Pin));
  assert_param(IS_FUNCTIONAL_STATE(NewState));

  if (NewState != DISABLE) /* External Pull-Up Set*/
  {
    GPIOx->CR1 |= GPIO_Pin;
  } else /* External Pull-Up Reset*/
  {
    GPIOx->CR1 &= (uint8_t)(~(GPIO_Pin));
  }
}

/**
  * @}
  */

/**
  * @}
  */
  
/**
  * @}
  */  
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
