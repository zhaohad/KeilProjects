
#ifndef	__SOFT_UART_H
#define	__SOFT_UART_H

#include	"config.h"

void	TxSend(u8 dat);
void 	PrintString(unsigned char code *puts);

#endif
